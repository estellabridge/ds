#include "StringLinkedList.cpp"

int main() {
    StringLinkedList sl = StringLinkedList();
    
    sl.addFront("1");

    cout << sl.front() << endl;

    return 0;
}


